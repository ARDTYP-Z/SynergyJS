import logo from './logo.svg';
import './App.css';
import React from "react";


const react = <h1>Hello react</h1>
function Hello() {
  return (
      <>
        { react }
      </>
);
}

export default Hello;
