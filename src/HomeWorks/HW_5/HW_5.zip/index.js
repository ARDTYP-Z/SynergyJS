import React, {useContext, useState} from 'react';
import ReactDOM from 'react-dom/client';
import Btn from "./Form";
import reportWebVitals from "./reportWebVitals";


const root = ReactDOM.createRoot(document.
getElementById('root'));


root.render(
  <div>
    <Btn />
  </div>
);
reportWebVitals();