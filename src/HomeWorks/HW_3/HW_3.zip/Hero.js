import React from 'react';


let Hero = () => {
  return (
    <>
      <h1 className="title">Supermarket</h1>
      <p>Start shopping</p>
    </>
  )
}

export default Hero