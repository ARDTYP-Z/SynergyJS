import React from 'react';


let Hero1 = () => {
  return (
    <div>
      <h1>Добро пожаловать в наш магазин</h1>
      <p>Начать покупки!</p>
    </div>
  )
}

export default Hero1