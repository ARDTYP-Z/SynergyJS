import React from 'react';

import Welcome from "./Welcome";

let WelcomeMain = () => {
  return(
    <div>
      <Welcome name={"Liza"}/>
      <Welcome name={"Dany"}/>
      <Welcome name={"Alex"}/>
    </div>
  )
}

export default WelcomeMain
