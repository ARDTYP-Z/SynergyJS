import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import reportWebVitals from './reportWebVitals';
import Counter from "./HomeWork_2";


const root = ReactDOM.createRoot(document.
getElementById('root'));

root.render(
    <div>
        <Counter />
    </div>
);
reportWebVitals();
